package com.liftmania;

import com.liftmania.Lift;
import com.liftmania.LiftController;


public class LiftControllerModel {
}
