package com.uom.cps3225;

import com.uom.cps3225.LiftController;
import com.uom.cps3225.Lift;
import nz.ac.waikato.modeljunit.timing.TimedFsmModel;
import nz.ac.waikato.modeljunit.timing.TimedModel;

public class LiftControllerModel implements TimedFsmModel {
}
